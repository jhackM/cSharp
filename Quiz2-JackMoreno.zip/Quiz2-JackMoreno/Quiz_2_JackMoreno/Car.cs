﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz_2_JackMoreno
{
    class Car
    {
        public string make;
        public string year;
        public bool status;

        public Car()
        {
            string make;
            string year;
            bool status;
        }

        public Car(string aMake, string aYear, bool aStatus)
        {
            this.make = aMake;
            this.year = aYear;
            this.status = aStatus;
        }

      

    }
}
