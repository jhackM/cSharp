﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz_2_JackMoreno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            
            
            

        }

        private void btnResetClicked(object sender, EventArgs e)
        {
            txtMake.Clear();
            txtYear.Clear();
            rbtnNew.Checked = true;

        }

        private void btnSaveClicked(object sender, EventArgs e)
        {
            Car car = new Car();
            car.make = txtMake.Text;
            car.year = txtYear.Text;
            if (rbtnNew.Checked == true)
                car.status = rbtnNew.Enabled;
            else car.status = rbtnUsed.Enabled;



            string aMake = txtMake.Text;
            string aYear = txtYear.Text;
            string aStatus;

            if (rbtnNew.Checked)
            {
                aStatus = "New";
            }
            else
                aStatus = "Used";
            

            MessageBox.Show($"Make: {aMake} \n Year: {aYear} \n Status: {aStatus}");
        }
    }
}
