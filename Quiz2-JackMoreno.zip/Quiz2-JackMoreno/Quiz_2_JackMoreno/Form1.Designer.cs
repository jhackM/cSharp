﻿namespace Quiz_2_JackMoreno
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmake = new System.Windows.Forms.Label();
            this.lblyear = new System.Windows.Forms.Label();
            this.txtMake = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.rbtnNew = new System.Windows.Forms.RadioButton();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblstatus = new System.Windows.Forms.Label();
            this.rbtnUsed = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lblmake
            // 
            this.lblmake.AutoSize = true;
            this.lblmake.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmake.Location = new System.Drawing.Point(32, 32);
            this.lblmake.Name = "lblmake";
            this.lblmake.Size = new System.Drawing.Size(42, 13);
            this.lblmake.TabIndex = 0;
            this.lblmake.Text = "Make:";
            // 
            // lblyear
            // 
            this.lblyear.AutoSize = true;
            this.lblyear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblyear.Location = new System.Drawing.Point(36, 68);
            this.lblyear.Name = "lblyear";
            this.lblyear.Size = new System.Drawing.Size(37, 13);
            this.lblyear.TabIndex = 1;
            this.lblyear.Text = "Year:";
            // 
            // txtMake
            // 
            this.txtMake.Location = new System.Drawing.Point(75, 26);
            this.txtMake.Name = "txtMake";
            this.txtMake.Size = new System.Drawing.Size(250, 20);
            this.txtMake.TabIndex = 2;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(75, 62);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(250, 20);
            this.txtYear.TabIndex = 3;
            // 
            // rbtnNew
            // 
            this.rbtnNew.AutoSize = true;
            this.rbtnNew.Checked = true;
            this.rbtnNew.Location = new System.Drawing.Point(75, 102);
            this.rbtnNew.Name = "rbtnNew";
            this.rbtnNew.Size = new System.Drawing.Size(47, 17);
            this.rbtnNew.TabIndex = 0;
            this.rbtnNew.TabStop = true;
            this.rbtnNew.Text = "New";
            this.rbtnNew.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(156, 150);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnResetClicked);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(250, 150);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSaveClicked);
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstatus.Location = new System.Drawing.Point(27, 104);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(47, 13);
            this.lblstatus.TabIndex = 7;
            this.lblstatus.Text = "Status:";
            // 
            // rbtnUsed
            // 
            this.rbtnUsed.AutoSize = true;
            this.rbtnUsed.Location = new System.Drawing.Point(128, 102);
            this.rbtnUsed.Name = "rbtnUsed";
            this.rbtnUsed.Size = new System.Drawing.Size(50, 17);
            this.rbtnUsed.TabIndex = 8;
            this.rbtnUsed.TabStop = true;
            this.rbtnUsed.Text = "Used";
            this.rbtnUsed.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(357, 195);
            this.Controls.Add(this.rbtnUsed);
            this.Controls.Add(this.lblstatus);
            this.Controls.Add(this.rbtnNew);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.txtMake);
            this.Controls.Add(this.lblyear);
            this.Controls.Add(this.lblmake);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmake;
        private System.Windows.Forms.Label lblyear;
        private System.Windows.Forms.TextBox txtMake;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.RadioButton rbtnNew;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.RadioButton rbtnUsed;
    }
}

