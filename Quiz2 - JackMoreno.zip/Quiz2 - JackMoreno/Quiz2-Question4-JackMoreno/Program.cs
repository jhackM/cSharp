﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz2_Question4_JackMoreno
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            List<int> list = new List<int>();
            list.Add(10);
            list.Add(30);
            list.Add(500);
            list.Add(90);
            list.Add(79);
            list.Add(250);
            list.Add(199);
            list.Add(89);
            list.Add(288);
            list.Add(1);

            Console.WriteLine("\nThe members of the list are : (INPUT)");
            foreach (var numList in list)
            {
                Console.Write(numList + " ");
            }
            List<int> FList = list.FindAll(x => x > 80 ? true : false);
            Console.WriteLine("\n\nThe numbers greater than 80 are : (OUTPUT)");
            foreach (var num in FList)
            {
                Console.WriteLine(num);
            }
            Console.ReadLine();
        }
    }
}
