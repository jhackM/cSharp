﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz2_JackMoreno
{
    public class Student
    {
        //public static List<Person> LoadSampleData()
        //{
        //    List<Person> output = new List<Person>();

        //    output.Add(new Person { Id = 1, FirstName = "Jhonny", LastName = "Bravo", Registered = true });
        //    output.Add(new Person { Id = 2, FirstName = "Maria", LastName = "Mercedes", Registered = true });
        //    output.Add(new Person { Id = 3, FirstName = "Marl", LastName = "Boro", Registered = true });
        //    output.Add(new Person { Id = 4, FirstName = "Dexter", LastName = "Lab", Registered = true });
        //    output.Add(new Person { Id = 5, FirstName = "Jet", LastName = "Lee", Registered = true });

        //    return output;
        //}
    }
}
