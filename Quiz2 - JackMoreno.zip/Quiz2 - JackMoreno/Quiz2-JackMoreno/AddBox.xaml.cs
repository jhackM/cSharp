﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quiz2_JackMoreno
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class AddBox : UserControl
    {
        public AddBox()
        {
            InitializeComponent();

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
           // MessageBox.Show($"{count} total number of students");
        }

        private void btnResetAddForm_Click(object sender, RoutedEventArgs e)
        {
            txtFName.Clear();
            txtLName.Clear();
            cbreg.IsChecked = false;
        }
    }
}
